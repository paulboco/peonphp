<?php

/*
|--------------------------------------------------------------------------
| Password Hashing
|
| This code is based on the answer at:
| http://stackoverflow.com/questions/4795385/how-do-you-use-bcrypt-for-hashing-passwords-in-php?answertab=votes#answer-6337021
|
| Load this file in a browser and repeatedly refresh (F5) the page.
| The displayed hashes are never the same, but
| are verified as equal each refresh.
| WTF!
|
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| Configuration
|
| Replace this password with your user's password to generate
| an encrypted hash to store in the database.
|--------------------------------------------------------------------------
*/

$password = 'd1nGLe b3RRy';

/*
|--------------------------------------------------------------------------
| Require password compatibility functions.
|--------------------------------------------------------------------------
*/

require 'password_compat.php';

/*
|--------------------------------------------------------------------------
| Hash the password twice and verify it as many times.
|
| These two functions, 'password_hash' and 'password_verify'
|                       -------------       ---------------
|
| are the most interesting thing to take away from this file.
|--------------------------------------------------------------------------
*/

$hash1 = password_hash($password, PASSWORD_DEFAULT);
$hash2 = password_hash($password, PASSWORD_DEFAULT);
$equal1 = password_verify($password, $hash1);
$equal2 = password_verify($password, $hash2);

/*
|--------------------------------------------------------------------------
| Display both hashed passwords and their equality.
|
| Using a PHP Heredoc syntax for the view.
|
| Heredoc info can be found here:
|     http://php.net/manual/en/language.types.string.php#language.types.string.syntax.heredoc
|
|--------------------------------------------------------------------------
*/

// translate boolean to string 'true' or 'false'
$equal1 = $equal1 ? 'true' : 'false';
$equal2 = $equal2 ? 'true' : 'false';

echo <<<EOD
<pre>

    Configured Password: "$password"
    -----------------------------------

        hash1: $hash1
        hash2: $hash2

        equal1: $equal1
        equal2: $equal2
</pre>
EOD;
